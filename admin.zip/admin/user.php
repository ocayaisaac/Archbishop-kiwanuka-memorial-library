<link rel="stylesheet" href="./add_admin.css"/>
<?php include ('header.php'); ?>

 
                <h3><center>
					Library Members Registred
                </h3>
     <hr>
</center>
                 <center>
							<a href="add_user.php">
							<button class="addmember" style=" background-color: rgb(0, 255, 38);">Add Member</button>
							</a>

							<br>
                         <br>
							
							<table cellpadding="13" cellspacing="1" border="2" class="table table-striped table-bordered" id="example">
								
							<thead>

								<tr style="background-color:blue;">
								<th style="width:100px;">Image</th>
									<th style="width:200px;">School ID</th>
									<th style="width:200px;">contact</th>
									<th style="width:200px;">Member Full Name</th>
									<th style="width:200px;">Type</th>
									<th style="width:100px;">Faculty</th>
									<th style="width:100px;">presence</th>
									<th style="width:200px;">Action</th>
									
								</tr>
							
							</thead>
							<tbody>
							
							<?php
							$result= mysqli_query($con,"select * from user order by user_id DESC") or die (mysqli_error());
							while ($row= mysqli_fetch_array ($result) ){
							$id=$row['user_id'];
							?>
							<tr>
									<td>
								<?php  if( $row['user_image'] != ""): ?>
								<img src="upload/<?php  echo $row['user_image']; ?>" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
								<?php  else: ?>

								<img src="images/user.png" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
								<?php  endif; ?>
								 

								<td><a target="_blank" ><?php echo $row['school_number']; ?></a></td> 
								<td><?php echo $row['contact']; ?></td> 
								<td><?php echo $row['firstname']." ".$row['middlename']." ".$row['lastname']; ?></td> 
								<td><?php echo $row['type']; ?></td> 
								<td><?php echo $row['faculty']; ?></td> 
								<td><?php echo $row['presence']; ?></td> 
								
							
								<td>
									<button style=" width:120px; height:40px; border-radius:7px;">
									<a class="btn btn-primary" for="ViewAdmin" href="view_user.php<?php echo '?user_id='.$id; ?>">
										VIEW
									</a>
								</button><br>
								<button style=" width:120px; height:40px; border-radius:7px;">
									<a class="btn btn-warning" for="ViewAdmin" href="edit_user.php<?php echo '?user_id='.$id; ?>">
									EDIT
									</a>
								</button><br>
							<button style="background-color:red; width:120px; height:40px; border-radius:7px;">
									<div id="delete<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
												<a href="delete_user.php<?php echo '?user_id='.$id; ?>" style="margin-top:20px;" class="btn btn-primary"> DELETE</a>
								</button><br>
											</div>
										</div>
										
									
							
								</td> 
							</tr>
							<?php } ?>
							</tbody>
							</table>
			
								</center>
<?php include ('footer.php'); ?>