<?php

			include ('include/dbcon.php');
						$query = mysqli_query($con,"SELECT * FROM `barcode` ORDER BY mid_barcode DESC ") or die (mysqli_error());
						$fetch = mysqli_fetch_array($query);
						$mid_barcode = $fetch['mid_barcode'];
						$new_barcode =  $mid_barcode + 1;
						$pre_barcode = "8UMU8";
						$suf_barcode = "LIB";
						$generate_barcode = $pre_barcode.$new_barcode.$suf_barcode;
?>

<link rel="stylesheet" href="./add_admin.css"/>
<?php include ('header.php'); ?>

       <center>
        
                            <form method="post" enctype="multipart/form-data" class="form-horizontal form-label-left" style=" background-color:rgb(200, 255, 255); border-radius:10px;">
							
                            <h3>
					Add a Book
                </h3>
        
                        <p>Fill in the details of the book below</p>
                 
<br><br>
                            
                            <input type="hidden" name="new_barcode" value="<?php echo $new_barcode; ?>">
							
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Title <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="book_title" id="first-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Author 1 <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="author" id="first-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Author 2
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="author_2" id="first-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Author 3
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="author_3" id="first-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Author 4
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="author_4" id="first-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Author 5
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="author_5" id="first-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                              
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Publisher<span class="required" style="color:red;">*</span>
                                    </label>
                                   
                                </div>
                                <div class="form-group">
                                   
                                    <div class="col-md-4">
                                        <input type="text" name="isbn" id="last-name2" class="form-control col-md-7 col-xs-12" required="required" style="height:50px;">
                                    </div>
                                </div>
                             
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Copies <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-1">
                                        <input type="number" name="book_copies" step="1" min="0" max="1000" required="required"  class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Category <span class="required" style="color:red;">*</span>
                                    </label>
									<div class="col-md-4">
                                        <select name="category_id" class="select2_single form-control" tabindex="-1" required="required" style="height:50px;">
										<?php
										$result= mysqli_query($con,"select * from category") or die (mysqli_error());
										while ($row= mysqli_fetch_array ($result) ){
										$id=$row['category_id'];
										?>
                                            <option value="<?php echo $row['category_id']; ?>"><?php echo $row['classname']; ?></option>
										<?php } ?>
                                        </select>
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name"><b>Book Image</b>
                                    </label>
                                    <div class="col-md-4"><br>
                                        <input type="file" style="height:44px;" name="image" id="last-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                               
                               <br><br><br><br>
                                    <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                                        <a href="book.php"><button type="button" class="cancelbutton" style="width:200px; height:40px;  background-color:red;"> Cancel</button></a>
                                        <button type="submit" name="submit" class="submitbutton" style="width:200px; height:40px;  background-color: rgb(0, 255, 38);"> Submit</button>
                                    </div>
                                
                            </form>
                                        </center>
            <?php

			include ('include/dbcon.php');
			if (!isset($_FILES['image']['tmp_name'])) {
			echo "";
			}else{
			$file=$_FILES['image']['tmp_name'];
			$image = $_FILES["image"] ["name"];
			$image_name= addslashes($_FILES['image']['name']);
			$size = $_FILES["image"] ["size"];
			$error = $_FILES["image"] ["error"];
			{
						if($size > 10000000)
						{
						die("Format is not allowed or file size is too big!");
						}
						
					else
						{

					move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $_FILES["image"]["name"]);			
					$book_image=$_FILES["image"]["name"];
					
					$book_title=$_POST['book_title'];
					$category_id=$_POST['category_id'];
					$author=$_POST['author'];
					$author_2=$_POST['author_2'];
					$author_3=$_POST['author_3'];
					$author_4=$_POST['author_4'];
					$author_5=$_POST['author_5'];
					$book_copies=$_POST['book_copies'];
					
					
					$pre = "8UMU8";
					$mid = $_POST['new_barcode'];
					$suf = "LIB";
					$gen = $pre.$mid.$suf;
					
				
					
					{
					mysqli_query($con,"insert into book (book_title,category_id,author,author_2,author_3,author_4,author_5,book_copies,book_barcode,book_image,date_added)
					values('$book_title','$category_id','$author','$author_2','$author_3','$author_4','$author_5','$book_copies','$gen','$book_image',NOW())")or die(mysqli_error());
					
					mysqli_query($con,"insert into barcode (pre_barcode,mid_barcode,suf_barcode) values ('$pre', '$mid', '$suf') ") or die (mysqli_error());
                    echo "<script>alert('Book successfully added!'); window.location='add_book.php'</script>";	
                }
                }
                }
            }
            ?>
						
           
        <br><br><br><br>			

<?php include ('footer.php'); ?>