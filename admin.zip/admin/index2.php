<?php include ('sidebar_menu.php'); 
?>

<!DOCTYPE html>
<html>
<head>
<title>penalties</title>
</head>
<body>
	<div><center>
		<h2>Edit Penalties</h2>
		<table cellpadding="12" cellspacing="1" border="2">
			<thead style=" background-color:blue;">
				<th  style="width:200px">USER ID</th>
				<th  style="width:200px">PENALTY</th>
				<th  style="width:200px">Action</th>
			</thead>
			<tbody>
				<?php
				
					include ('dbcon.php');
					$query=mysqli_query($con,"select * from `return_book`");
					while($row=mysqli_fetch_array($query)){
						?>
						<tr>
							<td><?php echo $row['user_id']; ?></td>
							<td><?php echo $row['book_penalty']; ?></td>
							<td>
								
								<a href="editpen.php?id=<?php echo $row['user_id']; ?>"><button style="width:100px; height:40px; background-color:pink;"> Edit </button></a>
					
							</td>
						</tr>
						<?php
					}
				?>
			</tbody>
		</table></center>
	</div>
	<?php include ('footer.php'); ?>
</body>
</html>