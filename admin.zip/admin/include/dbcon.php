<?php
$con = mysqli_connect('localhost','root','','UMULIBRARY')or die(mysqli_error());
?>