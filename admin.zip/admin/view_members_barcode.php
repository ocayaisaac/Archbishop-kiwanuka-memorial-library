<?php

include ('include/dbcon.php');

$code = $_GET['code'];
							$result1= mysqli_query($con,"select * from user where school_number = '$code' ") or die (mysqli_error());
							$row1=(mysqli_fetch_array($result1));
							$code1=$row1['school_number'];
							$code2=$row1['firstname']." ".$row1['middlename']." ".$row1['lastname'];
							$code3=$row1['faculty'];

?>
<?php include ('header.php'); ?>

   
                <h3>
					Members View Image
                </h3>
   
                        <h2><i class="fa fa-barcode"></i> Barcode Image</h2>
                      
							<a href="print_barcode_individual.php?code=<?php echo $code1; ?>" target="_blank" style="background:none;">
							<button class="btn btn-danger pull-right"><i class="fa fa-print"></i> Print Members Barcode</button>
							</a>
                    
	<center>	
	<div style="width: 400px; margin-bottom:60px; background-color: #fff;margin-top: 50px;border-radius: 8px;box-shadow: 1px 1px 1px 1px maroon;" > <!-- /content -->
		<h4 style="line-height:40px;">Barcode Image</h4>
		<div>
			<div class="clearfix"></div>
			<hr style="margin-top: 10px; color: black; border:1px solid;width: 90%;"/>
			<?php	echo "<img style='border:2px solid black; padding:15px;' src = 'BCG/html/image.php?filetype=PNG&dpi=72&scale=1&rotation=0&font_family=Arial.ttf&font_size=8&text=".$code."&thickness=30&start=NULL&code=BCGcode128' />";?>
			<h3><?php echo $code2; ?></h3>
			<h3><?php echo $code3; ?></h3>
			<hr style=" color: black; border:1px solid;width: 90%;"/>
			<div class="clearfix"></div>
				<a class="btn btn-primary" href="user.php"><i class="icon-ok"></i> Ok</a>
			
		</div>
	</div>
</center>
		

<?php include ('footer.php'); ?>