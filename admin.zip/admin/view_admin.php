<?php include ('header.php'); ?>
<br><br><br><br>
        <br><BR>
                <center>

                        <h2>Admin Information</h2>
    
                  </center>
						<div class="table-responsive">
							<table cellpadding="9" cellspacing="1" border="4">
								
							<thead>
								<tr>
									<th style="width:500px;">Image</th>
									<th style="width:500px;">First Name</th>
									<th style="width:500px;">Middle Name</th>
									<th style="width:500px;">Last Name</th>
									<th style="width:500px;">Username</th>
									<th style="width:500px;">Password</th>
									<th style="width:500px;">Date Added</th>
								</tr>
							</thead>
							<tbody>
<?php
			   
		if (isset($_GET['admin_id']))
		$id=$_GET['admin_id'];
		$result1 = mysqli_query($con,"SELECT * FROM admin WHERE admin_id='$id'");
		while($row = mysqli_fetch_array($result1)){
		?>
							<tr>
								<td>
									<?php if($row['admin_image'] != ""): ?>
									<img src="upload/<?php echo $row['admin_image']; ?>" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
									<?php else: ?>
									<img src="images/user.png" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
									<?php endif; ?>	
								</td> 
								<td><?php echo $row['firstname']; ?></td> 
								<td><?php echo $row['middlename']; ?></td> 
								<td><?php echo $row['lastname']; ?></td> 
								<td><?php echo $row['username']; ?></td> 
								<td><?php echo $row['password']; ?></td> 
								<td><?php echo date("M d, Y h:m:s a", strtotime($row['admin_added'])); ?></td> 
							</tr>
							<?php } ?>
							</tbody>
							</table>
						</div>
		

<?php include ('footer.php'); ?>