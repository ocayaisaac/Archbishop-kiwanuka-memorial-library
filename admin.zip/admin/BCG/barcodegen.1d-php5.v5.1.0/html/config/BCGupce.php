<?php
$classFile = 'BCGupce.barcode.php';
$className = 'BCGupce';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.0.2';
?>