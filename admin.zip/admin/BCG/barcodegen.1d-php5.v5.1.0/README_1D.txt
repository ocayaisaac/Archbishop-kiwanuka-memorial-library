This script is free for personal use. The program is provide "AS IS"
without warranty of any kind. If you want to use it as
commercial use, you have to purchase it on
http://www.barcodephp.com
You must let the copyright intact.

Ce script est gratuit pour usage personnel. Le programme est
fourni "TEL QUEL" sans aucune garantie que ce soit.
Si vous voulez l'utiliser pour un usage commercial,
vous devez l'acheter sur
http://www.barcodephp.com
Vous devez laisser les droits d'auteur intacts.