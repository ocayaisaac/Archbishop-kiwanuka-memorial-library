
<?php
include ('sidebar_menu.php');
include ('include/dbcon.php');
   ?>   
   <center>

                     <br>                 <h2>Allowable days</h2>
                           	<hr>

                                <div class="x_content">
                                    <table cellpadding="12" cellspacing="1" border="2">
                                        <thead>
                                            <tr>
                                                <th style="width:300px; height:50px;">Number of Day/Days</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
							<?php
							$penalty_query= mysqli_query($con,"select * from allowed_days order by allowed_days_id DESC ") or die (mysqli_error());
							while ($row33= mysqli_fetch_array ($penalty_query) ){
							$allowed_days_id=$row33['allowed_days_id'];
							?>
                                            <tr>
                                                <td><?php echo $row33['no_of_days']; ?><b> Days</b></td>
                                               
									<!-- edit modal -->
									<div class="modal fade" id="days_edit<?php  echo $allowed_days_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="myModalLabel"> ***********Edit number of allowed days in the box below***********</h4>
										</div>
										<div class="modal-body">
												<?php
												$query2=mysqli_query($con,"select * from allowed_days where allowed_days_id='$allowed_days_id'")or die(mysqli_error());
												$row44=mysqli_fetch_array($query2);
												?>
												<form method="post" enctype="multipart/form-data" class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-md-4" for="first-name" >Day or Days <span class="required">*</span>
														</label>
														<div class="col-md-3">
															<input style="height:60px; width:200px; font-size: 25px;" type="number" min="0" max="5" step="1" name="no_of_days" value="<?php echo $row44['no_of_days']; ?>" id="first-name2" class="form-control">
														</div>
													</div>
													<div class="modal-footer" style="margin-top:50px;">
													<p>Click Yes to confirm or No to Revert.</p>
													<button class="btn btn-inverse" style="margin-bottom:5px; margin-right:100px; color:white; background-color:red; height:50px; width:100px;" data-dismiss="modal" aria-hidden="true"><i class="glyphicon glyphicon-remove icon-white"></i> No</button>
													<button type="submit" style="margin-bottom:5px; color:white; background-color:cyan; height:50px; width:100px;" name="update" class="btn btn-primary"><i class="glyphicon glyphicon-ok icon-white"></i> Yes</button>
													</div>
												</form>
												<br><br>
												<?php
													if (isset($_POST['update'])) {
													
													$no_of_days1 = $_POST['no_of_days'];
													
													{
														mysqli_query($con," UPDATE allowed_days SET no_of_days='$no_of_days1' ") or die (mysqli_error());
													}
													{
														echo "<script>alert('Edit Successfully!'); window.location='home.php'</script>";
													}
														
													}
												?>
												
										</div>
										</div>
									</div>
									</div>
												
                                            </tr>
							<?php } ?>
                                        </tbody>
                                    </table>
                                </div>
								
                            </div>
                        </div></center>
						<?php include ('footer.php'); ?>