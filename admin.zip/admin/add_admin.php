<link rel="stylesheet" href="./add_admin.css">
<?php include ('header.php'); ?>
        <center>
                            <form method="post" enctype="multipart/form-data" class="form-horizontal form-label-left" style=" background-color:rgb(200, 255, 255); border-radius:10px;">
                            <h3>
					Add an Administrator<hr>
                </h3><br><br>
                 <p>Fill in the details below</p><br><br>
                            <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">First Name <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-3">
                                        <input type="text" name="firstname" id="first-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name" >Middle Name
                                    </label>
                                    <div class="col-md-3">
                                        <input type="text" name="middlename" id="first-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Last Name <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-3">
                                        <input type="text" name="lastname" id="last-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">User Name <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="username" id="last-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Password <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="password" name="password" id="last-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div><br>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Confirm Password <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="password" name="confirm_password" id="last-name2" required="required" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div><br><br>
                      
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name"><b>Admin Image</b>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="file" style="height:44px;" name="image" id="last-name2" class="form-control col-md-7 col-xs-12" style="height:50px;">
                                    </div>
                                </div>
                              
                                <div>
                                  <br>
                         <a href="admin.php"><button type="button" class="cancelbutton" style="width:200px; height:40px;  background-color:red;"> Cancel</button></a><br><br><br>
                               </div>
                                        <div><br>
                                        <button type="submit" name="submit" class="submitbutton" style="width:200px; height:40px;  background-color: rgb(0, 255, 38); margin-left:300px;"> Submit</button>
                                    
                                </div><br><br><br>
                            </form>
							
							<?php	
							include ('include/dbcon.php');
							if (!isset($_FILES['image']['tmp_name'])) {
							echo "";
							}else{
							$file=$_FILES['image']['tmp_name'];
							$image = $_FILES["image"] ["name"];
							$image_name= addslashes($_FILES['image']['name']);
							$size = $_FILES["image"] ["size"];
							$error = $_FILES["image"] ["error"];
							{
										if($size > 10000000) 
										{
										die("Format is not allowed or file size is too big!");
										}
										
									else
										{

									move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $_FILES["image"]["name"]);			
									$profile=$_FILES["image"]["name"];
									$firstname = $_POST['firstname'];
									$middlename = $_POST['middlename'];
									$lastname = $_POST['lastname'];
									$username = $_POST['username'];
									$password = $_POST['password'];
									$confirm_password = $_POST['confirm_password'];
					
					
					$result=mysqli_query($con,"select * from admin WHERE username='$username' ") or die (mysqli_error());
					$row=mysqli_num_rows($result);
					if ($row > 0)
					{
					echo "<script>alert('Username already taken!'); window.location='add_admin.php'</script>";
					}
					elseif($password != $confirm_password)
					{
					echo "<script>alert('Password do not match!'); window.location='add_admin.php'</script>";
					}else
					{		
						mysqli_query($con,"insert into admin (firstname, middlename, lastname, username, password, confirm_password, admin_image, admin_type, admin_added)
						values ('$firstname', '$middlename', '$lastname', '$username', '$password', '$confirm_password', '$profile', 'Admin', NOW())")or die(mysqli_error());
						echo "<script>alert('Account successfully added!'); window.location='admin.php'</script>";
					}
									}
									}
							}
								?>
						
                     
                    </div>
                </div>
            </div>
        </div>
        </center>
<?php include ('footer.php'); ?>