<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="./sidebar.css">
    <title>Admin Dashboard</title> 
</head>
<body>
  <div style="background-color:bisque;">
<img src="./library.png" width=500px  style="margin-bottom:-100px;">
     <div class="image">
    <img src="./man.PNG" style="width: 70px; margin-top:10px; margin-left:1180px;" height="70px;" alt="">
  <center>
  <button class"button" style="margin-left:1050px; border-radius:15px;">  <a href="logout.php"> <img src="./switch.png" height=50px></a> 
 </button>
<h3 style="margin-top:-25px;"><b>ADMIN DASHBOARD</b></h3>
</div>

<ul style="margin-left:130px;" class="sider">
  <li><a href="./home.php">Home</a></li> 
   <li><a href="admin.php"> Admin</a></li>
  <li><a href="./user.php">Members</a></li>
  <li><a href="./book.php">Books</a></li>
  <li><a href="./borrow.php">Borrow</a></li>
  <li><a href="./borrowed.php">Borrowed Books</a></li>
  <li><a href="./returned_book.php">Returned Books</a></li>
  <li><a href="./borrowees.php">Check Out Of Books</a></li>
  <li><a href="./index2.php">Check Out Of Penalties</a></li>
  <li><a href="./allowed_days.php">Edit allowed Days</a></li>
  <li><a href="./penalty.php">Handle Penalty</a></li>
  <li><a href="./allowed_qntty.php">Handle Allowed Books</a></li>
 <li><a href="./report.php">Reports</a></li>
 <li><a href="./mainpage.php">Feedback</a></li>
</ul>
</center>
<center>
</div>
<?php
	include('include/dbcon.php');
  require('session.php');
	$user_query=mysqli_query($con,"select * from admin where admin_id='$id_session'")or die(mysqli_error());
	$row=mysqli_fetch_array($user_query); {
?>
                                             
	
                            
<?php } ?>
           
     </div>
</center>  
  </body>
  </html>