<?php
include('include/dbcon.php');
      
	
	  include ('sidebar_menu.php');
	  ?>
			  <center>  
					  <br><p>Edit the allowed Books to be Borrowed by an Individual</p>
                          
			<hr>
                             
                                    <table cellpadding="12" cellspacing="1" border="2">
                                        <thead>
                                            <tr>
                                                <th style="width:300px; height:50px;">Quantity</th>
                                    
                                            </tr>
                                        </thead>
                                        <tbody>
							<?php
							$allowed_book_query= mysqli_query($con,"select * from allowed_book order by allowed_book_id DESC ") or die (mysqli_error());
							while ($row11= mysqli_fetch_array ($allowed_book_query) ){
							$id=$row11['allowed_book_id'];
							?>
                                            <tr>
                                                <td><?php echo $row11['qntty_books']; ?></td>
                                              
									<!-- edit modal -->
									<div class="modal fade" id="edit<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="myModalLabel">***********Edit number of allowed books in the box below***********</h4>
										</div>
										<div class="modal-body">
												<?php
												$query1=mysqli_query($con,"select * from allowed_book where allowed_book_id='$id'")or die(mysqli_error());
												$row22=mysqli_fetch_array($query1);
												?>
												<form method="post" enctype="multipart/form-data" class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-md-4" for="first-name">Quantity <span class="required">*</span>
														</label>
														<div class="col-md-3">
															<input style="height:60px; width:200px; font-size: 25px;"  type="number" min="0" max="100" step="1" name="qntty_books" value="<?php echo $row22['qntty_books']; ?>" id="first-name2" class="form-control">
														</div>
													</div>
													<div class="modal-footer" style="margin-top:50px;">
													<button  style="margin-bottom:5px; margin-right:100px; color:white; background-color:red; height:50px; width:100px;" class="btn btn-inverse" data-dismiss="modal" aria-hidden="true"><i class="glyphicon glyphicon-remove icon-white"></i> No</button>
													<button type="submit"  style="margin-bottom:5px; color:white; background-color:cyan; height:50px; width:100px;" name="update1" class="btn btn-primary"><i class="glyphicon glyphicon-ok icon-white"></i> Yes</button>
													</div>
												</form>
												<br><br>
												<?php
													if (isset($_POST['update1'])) {
													
													$qntty_books = $_POST['qntty_books'];
													
													{
														mysqli_query($con," UPDATE allowed_book SET qntty_books='$qntty_books' ") or die (mysqli_error());
													}
													{
														echo "<script>alert('Edit Successfully!'); window.location.href='home.php'</script>";
													}
														
													}
												?>
												
										</div>
										</div>
									</div>
									</div>
												
                                            </tr>
							<?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
						<?php include ('footer.php'); ?>