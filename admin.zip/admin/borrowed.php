<?php include ('header.php'); ?>
<br><br><br>
        
                <h3><center>
				Books that are Borrowed </center>
                </h3>
            <hr>
<br>
 

<center> 
						<form method="GET" action="" class="form-inline">
                                <div class="control-group">
                                    <div class="controls">
                                        <div class="col-md-3">
                                            <input type="date" style="color:black; color:black; height:60px; width:170px;" value="<?php echo date('Y-m-d'); ?>" name="datefrom" class="form-control has-feedback-left" placeholder="Date From" aria-describedby="inputSuccess2Status4" required />
                                            <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true" style="margin-left:100px;">
												  <input type="date" style="color:black; color:black; height:60px; width:170px;" value="<?php echo date('Y-m-d'); ?>" name="dateto" class="form-control has-feedback-left" placeholder="Date To" aria-describedby="inputSuccess2Status4" required />
                                            <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
											</span>
                                           
											
                          <button type="submit" name="search" class="btn btn-primary btn-outline" style="margin-left:300px; margin-top:-60px; background-color:magenta; height:60px; width:80px; border-radius:10px;"><i class="fa fa-calendar-o"></i> Search</button>
								  <br></div>
                                    </div>
                                </div>		
						</form>
					<br><br>
                    </div>
                    <div class="x_content">
                   

												
							<?php
							$where ="";
							if(isset($_GET['search'])){
								$where = " and (date(borrow_book.date_borrowed) between '".date("Y-m-d",strtotime($_GET['datefrom']))."' and '".date("Y-m-d",strtotime($_GET['dateto']))."' ) ";
							}
							
							$return_query= mysqli_query($con,"SELECT * from borrow_book 
							LEFT JOIN book ON borrow_book.book_id = book.book_id 
							LEFT JOIN user ON borrow_book.user_id = user.user_id 
							where borrow_book.borrowed_status = 'borrowed' $where order by borrow_book.borrow_book_id DESC") or die (mysqli_error());
								$return_count = mysqli_num_rows($return_query);
								
							
							?>
							<table cellpadding="12" cellspacing="1" border="2">
								
                               
							<thead>
								<tr style=" background-color:blue;">
									<th style="width:200px;">Barcode</th>
									<th style="width:200px;">Borrower Name</th>
									<th style="width:200px;">Title</th>
									<th style="width:200px;">Author</th>
									
									<th style="width:200px;">Date Borrowed</th>
									<th style="width:200px;">Due Date</th>
									 <th style="width:200px;">Date Returned</th> 
									<th style="width:200px;">Penalty</th> 
								</tr>
							</thead>
							<tbody>
<?php
							while ($return_row= mysqli_fetch_array ($return_query) ){
							$id=$return_row['borrow_book_id'];
?>
							<tr>
								<td><?php echo $return_row['book_barcode']; ?></td>
								<td style="text-transform: capitalize"><?php echo $return_row['firstname']." ".$return_row['lastname']; ?></td>
								<td style="text-transform: capitalize"><?php echo $return_row['book_title']; ?></td>
							<td style="text-transform: capitalize"><?php echo $return_row['author']; ?></td>
							
								<td><?php echo date("M d, Y h:m:s a",strtotime($return_row['date_borrowed'])); ?></td>
								<?php
								 if ($return_row['book_penalty'] != 'No Penalty'){
									 echo "<td class='' style='width:100px;'>".date("M d, Y h:m:s a",strtotime($return_row['due_date']))."</td>";
								 }else {
									 echo "<td>".date("M d, Y h:m:s a",strtotime($return_row['due_date']))."</td>";
								 }
								
								?>
								<?php
								  if ($return_row['book_penalty'] != 'No Penalty'){
									 echo "<td class='' style='width:100px;'>".date("M d, Y h:m:s a",strtotime($return_row['date_returned']))."</td>";
								  }else {
									  echo "<td>".date("M d, Y h:m:s a",strtotime($return_row['date_returned']))."</td>";
								  }
								
								?>
								<?php
								  if ($return_row['book_penalty'] != 'No Penalty'){
									 echo "<td class='alert alert-warning' style='width:100px;'>".$return_row['book_penalty']."</td>";
								  }else {
									  echo "<td>".$return_row['book_penalty']."</td>";
								 }
								
								?>
							</tr>
							
							<?php 
							}
							if ($return_count <= 0){
								echo '
									<table style="float:right;">
										<tr>
											<td style="padding:10px;" class="alert alert-danger">No Book returned</td>
										</tr>
									</table>
								';
							} 							
							?>
							</tbody>
							</table>
							</center>
<?php include ('footer.php'); ?>