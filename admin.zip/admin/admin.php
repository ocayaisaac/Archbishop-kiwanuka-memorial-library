<?php include ('header.php'); ?>
<br><br><br><br>
      <body stlye="background-color:rgb(219, 214, 214);">  
          <center>   
			   <h3> View, Edit or Add an Administrator</h3>
        
                      <hr> <h2 style="color:black; margin-bottom:-60px;">Administrators Registered</h2>
                      
<?php
$user_query  = mysqli_query($con,"select * from admin where admin_id = '$id_session'")or die(mysqli_error());
$user_row =mysqli_fetch_array($user_query);

?>
					
						<a href="add_admin.php" style="background:none;">
							<button class="btn btn-primary" style="margin-left:1000px; height:40px; background-color: rgb(0, 255, 38); border-radius:7px; width:150px;"> Add Admin</button><br><br><br>
							</a>	
					<?php  ?>
                  
							<table cellpadding="9" cellspacing="1" border="4">
								
							<thead>
								<tr style=" background-color:blue;">
									<th style="width:500px;">Image</th>
									<th style="width:500px;">Full Name</th>
									<th style="width:500px;">Action</th>
								</tr>
							</thead>
							<tbody>
							
							<?php
							$result= mysqli_query($con,"select * from admin order by admin_id ASC") or die (mysqli_error());
							while ($row= mysqli_fetch_array ($result) ){
							$id=$row['admin_id'];
							?>
							<tr>
								<td>
									<?php if($row['admin_image'] != ""): ?>
									<img src="upload/<?php echo $row['admin_image']; ?>" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
									<?php else: ?>
									<img src="images/user.png" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
									<?php endif; ?>	
								</td> 
								<td><?php echo $row['firstname']." ".$row['middlename']." ".$row['lastname']; ?></td>
						
								<td>
									<button style="width:120px; height:50px; border-radius:7px;">
									<a class="btn btn-primary" for="ViewAdmin" href="view_admin.php<?php echo '?admin_id='.$id; ?>">
										VIEW
									</a>
									</button>
									<button style="width:120px; height:50px; margin-top:100px; border-radius:7px;">
									<a class="btn btn-warning" for="ViewAdmin" href="edit_admin.php<?php echo '?admin_id='.$id; ?>">
										EDIT
									</a>
									</button>
									
									<button style="background-color:rgb(220, 57, 57);  border-radius:7px; margin-bottom:20px; width:120px; height:50px;">
									<div id="delete<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
												<div class="modal-footer">
												<a href="delete_admin.php<?php echo '?admin_id='.$id; ?>" style="margin-bottom:5px;" class="btn btn-primary">DELETE</a>
									
											</div>
                                                </button>

										</div>
										</div>
									</div>
									</div>
								</td> 
							</tr>
							<?php } ?>
							</tbody>
							</table>
							</center>
				
         
									</body>
<?php include ('footer.php'); ?>