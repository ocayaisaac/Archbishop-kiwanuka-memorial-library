<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="./sidebar.css"/>
    <title>Admin Dashboard</title> 
</head>
<body>

     <div class="image">
    <img src="man.png" style="width: 100px;" height="90px;" alt="">
</div>
<h3 style="margin-top:25px;">Admin Dashboard</h3>

   <center>

<ul style="margin-left:130px;" >
  <li><a href="./home.php">Home</a></li> 
   <li><a href="admin.php"><i class="fa fa-user"></i> Admin</a></li>
  <li><a href="./user.php">Members</a></li>
  <li><a href="./book.php">Books</a></li>
  <li><a href="./borrow.php">Borrow</a></li>
  <li><a href="./borrowed.php">Borrowed Books</a></li>
  <li><a href="./returned_book.php">Returned Books</a></li>
  <li><a href="./borrowees.php">Check Out Of Books</a></li>
  <li><a href="./index2.php">Check Out Of Penalties</a></li>
  <li><a href="./allowed_days.php">Edit allowed Days</a></li>
  <li><a href="./penalty.php">Handle Penalty</a></li>
  <li><a href="./allowed_qntty.php">Handle Allowed Books</a></li>
 <li><a href="./report.php">Reports</a></li>
 <li><a href="./mainpage.php">Feedback</a></li>
 
  <li>
</ul>
</center>
<center>

<?php
	include('include/dbcon.php');
  require('session.php');
	$user_query=mysqli_query($con,"select * from admin where admin_id='$id_session'")or die(mysqli_error());
	$row=mysqli_fetch_array($user_query); {
?>
                                             
	 <button style="margin-left:1030px; margin-top: -150px; text-color:red;"><a href="logout.php"> <button class"button" style="background-color:brown; border-radius: 10px;  color: white; height:40px; width:70px; margin-left:1050px; margin-top:-90px;"> Log Out</a> 
                                    
   </button>
                            
<?php } ?>
           
     </div>
</center>  
  </body>
  </html>