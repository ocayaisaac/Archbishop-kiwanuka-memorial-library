<link rel="stylesheet" href="./add_admin.css"/>
<?php include ('header.php'); ?>
 
                <h3><center>
					Library Feedbacks received
                </h3>
     <hr>
</center>

							<br><br>
                         
<center>
							<table cellpadding="13" cellspacing="1" border="2" class="table table-striped table-bordered" id="example">
								
							<thead>

								<tr style=" background-color:blue;">
								<th style="width:100px; height:40px;">NAME</th>
									<th style="width:140px; height:40px;">EMAIL</th>
									<th style="width:150px; height:40px;">CONTACT</th>
									<th style="width:400px; height:40px;">FEEDBACK</th>
									<th style="width:400px; height:40px;">SUGGESTIONS</th>
							
									
									
								</tr>
							
							</thead>
							<tbody>
							
							<?php
							$result= mysqli_query($con,"select * from poll") or die (mysqli_error());
							while ($row= mysqli_fetch_array ($result) ){
							;
							?>
							<tr>
				
								 

								 
								<td><?php echo $row['name']; ?></td> 
								<td><?php echo $row['email']; ?></td> 
								<td><?php echo $row['phone']; ?></td> 
								<td><?php echo $row['feedback']; ?></td> 
								<td><?php echo $row['suggestions']; ?></td> 
								
							
							
							</tr>
							<?php } ?>
							</tbody>
							</table>
							</center>	
<br><br><br>
<?php include ('footer.php'); ?>