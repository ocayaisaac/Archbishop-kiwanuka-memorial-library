<?php
	include ('dbcon.php');
	$id=$_GET['id'];
	
	$user_id=$_POST['user_id'];
	$book_penalty=$_POST['book_penalty'];
	
	mysqli_query($con,"update `return_book` set user_id='$user_id', book_penalty='$book_penalty' where user_id='$id'");
	header('location:index2.php');
?>