<link rel="stylesheet" href="./add_admin.css"/>
<?php include ('header.php'); ?>
<br><br>
     <center>
                <h3>
					Member Borrowing of a Book
                </h3>
          <hr>
	<br><br>

						<form method="post" action="">
                                        <select name="school_number" class="select2_single form-control" required="required" tabindex="2"  style="height:60px; width:400px;">
										<option value="0">Select School ID Number</option>
										<?php
										$result= mysqli_query($con,"select * from user where presence = 'Active' ") or die (mysqli_error());
										while ($row= mysqli_fetch_array ($result) ){
										$id=$row['user_id'];
										?>
                                            <option value="<?php echo $row['school_number']; ?>"><?php echo $row['school_number']; ?> - <?php echo $row['firstname']; ?></option>
										<?php } ?>
                                        </select>
				<br />
				<br />
				<br><br><br><br><br>
						<button name="submit" type="submit" class="submitbutton" style="margin-left:110px;">Submit</button>
						</form>

<?php
	include ('include/dbcon.php');

	if (isset($_POST['submit'])) {

	$school_number = $_POST['school_number'];

	$sql = mysqli_query($con,"SELECT * FROM user WHERE school_number = '$school_number' ");
	$count = mysqli_num_rows($sql);
	$row = mysqli_fetch_array($sql);

		if($count <= 0){
			echo "<div class='alert alert-success'>".'No match found for the School ID Number'."</div>";
		}else{
			$school_number = $_POST['school_number'];
			echo ('<script> location.href="borrow_book.php?school_number='.$school_number.'";</script');
		}
	}
?>

</center>
<?php include ('footer.php'); ?>