<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./home.css">
	<?php include ('header.php'); ?>
   
	

<br><br><br>
	<div>
        <div class="image">  
			<img src="./image44.jpg" style="height:400px; width:1400px; border-radius:10px; margin-top:-54px;">
			</div>	
				<div class="flex-container"  style="margin-top:-400px; margin-left:150px;">

                <div> <center>
					 <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
                        
                        <div class="right">
							<?php
							$result = mysqli_query($con,"SELECT * FROM admin");
							$num_rows = mysqli_num_rows($result);
							?>
				<a href="admin.php">
                            <span class="count_top" style="color:white;">Admin</span>
				</a>
                            <div class="count green"><?php echo $num_rows; ?></div>
							 <span class="count_bottom">Admins</span>

                        </div>
                    </div>
</div></center>
					<div>
                        <div class="left"></div>
                        <div class="right">
							<?php
							$result = mysqli_query($con,"SELECT * FROM user");
							$num_rows = mysqli_num_rows($result);
							?>
				<a href="user.php">
                            <span class="count_top" style="color:white;"> Library Members</span>
				</a>
                            <div class="count green"><?php echo $num_rows; ?></div>
							 <span class="count_bottom">Total</span>							
                        </div>
                    </div>
					<div>
                        <div class="left"></div>
                        <div class="right">
							<?php
							$result = mysqli_query($con,"SELECT * FROM book");
							$num_rows = mysqli_num_rows($result);
							?>
				<a href="book.php">
                            <span class="count_top" style="color:white;"> Books</span>
				</a>
                            <div class="count green"><?php echo $num_rows; ?></div>
							 <span class="count_bottom ">Total Books</span>                     
					  </div>
                    </div>
					<div>
                        <div class="left"></div>
                        <div class="right">
							<?php
							$result = mysqli_query($con,"SELECT * FROM borrow_book");
							$num_rows = mysqli_num_rows($result);
							?>
				<a href="borrowed.php">
                            <span class="count_top"style="color:white;"> Book Borrowed</span>
				</a>
                            <div class="count green"><?php echo $num_rows; ?></div>
							 <span class="count_bottom ">Total Books Borrowed</span>
                        </div>
                    </div>
					<div>
                      <div class="left"></div>
                        <div class="right">
							<?php
							$result = mysqli_query($con,"SELECT * FROM return_book");
							$num_rows = mysqli_num_rows($result);
							?>
				<a href="returned_book.php">
                            <span class="count_top" style="color:white;"> Total Books Returned</span>
				</a>
                            <div class="count green"><?php echo $num_rows; ?></div>
							 <span class="count_bottom ">Total Books Returned</span>							
                        </div>
                    </div>

                </div>
</div>   
	
				


				

