<?php include ('header.php'); ?>

        
                <h3><center>
					Books In the Catalogue of the Library
                     </center>
						 <hr>
						 <center>	
						 <a href="add_book.php" style="background:none;">
							<button class="btn btn-primary" style="height:40px; width:150px; background-color:pink;">Add Book</button>
							</a>
							</center>
							
                     
							
                <br><br>
					
				<table cellpadding="13" cellspacing="1" border="2" class="table table-striped table-bordered" id="example">
											
							<thead>
							<tr style="background-color:blue;">
									<th style="width:150px;">Book Image</th>
									<th style="width:200px;">Barcode</th>
									<th style="width:400px;">Title</th>
									<th>Author/s</th>
									<th style="width:90px;">Copies</th>
									<th style="width:150px;">Category</th>	
									<th style="width:150px;">Action</th>
								</tr>
							</thead>
							<tbody>
							
							<?php
							$result= mysqli_query($con,"select * from book order by book_id DESC ") or die (mysqli_error());
							while ($row= mysqli_fetch_array ($result) ){
							$id=$row['book_id'];
							$category_id=$row['category_id'];
							
							$cat_query = mysqli_query($con,"select * from category where category_id = '$category_id'")or die(mysqli_error());
							$cat_row = mysqli_fetch_array($cat_query);
							?>
							<tr>
								<td>
								<?php if($row['book_image'] != ""): ?>
								<img src="upload/<?php echo $row['book_image']; ?>" class="img-thumbnail" width="120px" height="170px">
								<?php else: ?>
								<img src="images/book_image.jpg" class="img-thumbnail" width="75px" height="50px">
								<?php endif; ?>
								</td> 
								<td><?php echo $row['book_barcode']; ?></a></td>
								<td style="word-wrap: break-word; width: 10em;"><?php echo $row['book_title']; ?></td>
								
								<td style="word-wrap: break-word; width: 10em;"><?php echo $row['author']."<br />".$row['author_2']."<br />".$row['author_3']."<br />".$row['author_4']."<br />".$row['author_5']; ?></td>
								<td><?php echo $row['book_copies']; ?></td> 
								<td><?php echo $cat_row['classname']; ?></td> 
								<td><br>

								<button style=" width:120px; height:40px; border-radius:7px;">
									<a class="btn btn-primary" for="ViewAdmin" href="view_book.php<?php echo '?book_id='.$id; ?>">
										View Book
									</a></button><br><br>
									<button style=" width:120px; height:40px; border-radius:7px;">
									<a class="btn btn-warning" for="ViewAdmin" href="edit_book.php<?php echo '?book_id='.$id; ?>">
									Edit Book
									</a></button><br><br>
								
									<button style=" width:120px; height:40px; border-radius:7px; background-color:red;">
									<div id="delete<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">	
									
									<a href="delete_book.php<?php echo '?book_id='.$id; ?>" style="margin-top:15px;" class="btn btn-primary"> Delete Book</a>
								</button>			</div>
										</div>
								<br></td> 
							</tr>
							<?php } ?>
							</tbody>
							</table>
						
						
            

<?php include ('footer.php'); ?>