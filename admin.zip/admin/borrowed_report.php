<?php include ('header.php'); ?>
<br>
      
            <center>
                <h3>
					Reports Borrowed
                </h3>
<hr>
      
                
                    
						<span>
					<?php 
					$count = mysqli_fetch_array(mysqli_query($con,"SELECT COUNT(*) as total FROM `report`")) or die(mysqli_error());
					$count1 = mysqli_fetch_array(mysqli_query($con,"SELECT COUNT(*) as total FROM `report` WHERE `detail_action` = 'Borrowed Book'")) or die(mysqli_error());
					$count2 = mysqli_fetch_array(mysqli_query($con,"SELECT COUNT(*) as total FROM `report` WHERE `detail_action` = 'Returned Book'")) or die(mysqli_error());
					?>
							<a href="report.php"><button class="btn btn-primary btn-outline"  style="background-color:brown; color:white; height:70px; width:180px; border-radius:5px;"> All Reports (<?php echo $count['total']; ?>)</button></a>
							<a href="borrowed_report.php"><button class="btn btn-success" style="background-color:cyan; color:white; height:70px; width:180px; border-radius:5px;"> Borrowed Reports (<?php echo $count1['total']; ?>)</button></a>
							<a href="returned_report.php"><button class="btn btn-danger btn-outline" style="background-color:brown; color:white; height:70px; width:180px; border-radius:5px;"> Returned Reports (<?php echo $count2['total']; ?>)</button></a>
						</span>
                     
                   <br><br><br>


						<div class="table-responsive">
						<table cellpadding="13" cellspacing="1" border="2" class="table table-striped table-bordered" id="example">
					
							<thead>
								<tr style=" background-color:blue;">
									<th style="width:300px;">Members Name</th>
									<th style="width:300px;">Book Title</th>
									<th style="width:300px;">Task</th>
									<th style="width:300px;">Date Transaction</th>
								</tr>
							</thead>
							<tbody>
							
							<?php
							$result= mysqli_query($con,"select * from report 
							LEFT JOIN book ON report.book_id = book.book_id 
							LEFT JOIN user ON report.user_id = user.user_id 
							where detail_action = 'Borrowed Book'
							order by report.report_id DESC ") or die (mysqli_error());
							while ($row= mysqli_fetch_array ($result) ){
							$id=$row['report_id'];
							$book_id=$row['book_id'];
							$user_name=$row['firstname']." ".$row['middlename']." ".$row['lastname'];
							
							?>
							<tr>
								<td><?php echo $user_name; ?></td>
								<td><?php echo $row['book_title']; ?></td>
								<td><?php echo $row['detail_action']; ?></td>
								
								<td><?php echo date("M d, Y h:m:s a",strtotime($row['date_transaction'])); ?></td>
							</tr>
							<?php } ?>
							</tbody>
							</table>
							</center><br><br>
<?php include ('footer.php'); ?>