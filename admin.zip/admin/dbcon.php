<?php
$con = mysqli_connect('localhost','root','','umulibrary')or die(mysqli_error());
?>