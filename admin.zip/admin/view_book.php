<?php include ('header.php'); ?>
<br><br><br><br><br><br>
     <center>
                <h3>
					View Book
                </h3>
</center>
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
								
							<thead>
								<tr>
									<th style="width:100px;">Book Image</th>
									<th>Barcode</th>
									<th>Title</th>
									<th>Author/s</th>
									
									
									<th>Publisher</th>
									
									<th>Copies</th>
									<th>Category</th>
								
								</tr>
							</thead>
							<tbody>
<?php
			   
		if (isset($_GET['book_id']))
		$id=$_GET['book_id'];
		$result1 = mysqli_query($con,"SELECT * FROM book 
		LEFT JOIN category on book.category_id = category.category_id 
		WHERE book_id='$id'");
		while($row = mysqli_fetch_array($result1)){
		?>
							<tr>
								<td>
								<?php if($row['book_image'] != ""): ?>
								<img src="upload/<?php echo $row['book_image']; ?>" width="150px" height="180px" style="border:4px groove #CCCCCC; border-radius:5px;">
								<?php else: ?>
								<img src="images/book_image.jpg" width="150px" height="180px" style="border:4px groove #CCCCCC; border-radius:5px;">
								<?php endif; ?>
								</td> 
								<td><?php echo $row['book_barcode']; ?></td>
								<td style="word-wrap: break-word; width: 10em;"><?php echo $row['book_title']; ?></td>
								<td style="word-wrap: break-word; width: 10em;"><?php echo $row['author']."<br />".$row['author_2']."<br />".$row['author_3']."<br />".$row['author_4']."<br />".$row['author_5']; ?></td>
							
								
								<td><?php echo $row['publisher_name']; ?></td>
							 
								<td><?php echo $row['book_copies']; ?></td> 
								<td><?php echo $row['classname']; ?></td> 
								
							</tr>
							<?php } ?>
							</tbody>
							</table>
						</div>
					
<?php include ('footer.php'); ?>