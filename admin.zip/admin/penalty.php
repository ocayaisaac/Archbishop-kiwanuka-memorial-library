<?php
include ('sidebar_menu.php');
include ('include/dbcon.php');
   ?>  
<br><center>



                                <div class="x_content">
                                    <table cellpadding="12" cellspacing="1" border="2">
                                        <thead>
                                            <tr>
                                                <th  style="width:300px; height:50px;">Amount (Shs)</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
							<?php
							$penalty_query= mysqli_query($con,"select * from penalty order by penalty_id DESC ") or die (mysqli_error());
							while ($row33= mysqli_fetch_array ($penalty_query) ){
							$penalty_id=$row33['penalty_id'];
							?>
                                            <tr>
                                                <td><?php echo $row33['penalty_amount']."".''; ?></td>
                                               
									<!-- edit modal -->
									<div class="modal fade" id="penalty_edit<?php  echo $penalty_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="myModalLabel">***********Edit number of allowed amount of penalty in the box below***********</h4>
										</div>
										<div class="modal-body">
												<?php
												$query2=mysqli_query($con,"select * from penalty where penalty_id='$penalty_id'")or die(mysqli_error());
												$row44=mysqli_fetch_array($query2);
												?>
												<form method="post" enctype="multipart/form-data" class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-md-4" for="first-name"><b>Amount </b><span class="required">*</span>
														</label>
														<div class="col-md-3">
															<input style="height:60px; width:200px; font-size: 25px;" type="number" min="0" max="10000" step="1" name="penalty_amount" value="<?php echo $row44['penalty_amount']; ?>" id="first-name2" class="form-control">
														</div>
													</div>
													<div class="modal-footer" style="margin-top:50px;">
													<p>Click Yes to confirm or No to Revert.</p>
													<button class="btn btn-inverse"  style="margin-bottom:5px; margin-right:100px; color:white; background-color:red; height:50px; width:100px;" data-dismiss="modal" aria-hidden="true"> No</button>
													<button type="submit" style="margin-bottom:5px; color:white; background-color:cyan; height:50px; width:100px;" name="submit" class="btn btn-primary">Yes</button>
													</div>
												</form>
												<br><br>
												<h2>The Allowed penalty is shown below</h2>
												<?php
													if (isset($_POST['submit'])) {
													
													$penalty_amount1 = $_POST['penalty_amount'];
													
													{
														mysqli_query($con," UPDATE penalty SET penalty_amount='$penalty_amount1' ") or die (mysqli_error());
													}
													{
														echo "<script>alert('Edit Successfully!'); window.location='home.php'</script>";
													}
														
													}
												?>
												
										</div>
										</div>
									</div>
									</div>
												
                                            </tr>
							<?php } ?>
                                        </tbody>
                                    </table>
                                </div>
								
                            </div>
                        </div>
						<?php include ('footer.php'); ?>