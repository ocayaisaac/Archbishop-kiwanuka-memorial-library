<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Administratorlogin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./index.css"/>
<link rel="stylesheet" href="./index.js"/>
</head>
<body>
<center style="background-color: #0096D6;">

<div class="div1">
<div class="first">
<div id="myPageContent" class="umuclass">
<img src="./umu.png" height="100px" width="100px">
        
                  
<h3 style="color: white;">ARCHBISHOP KIWANUKA MEMORIAL LIBRARY MANAGEMENT <br> SYSTEM</h3>
</div>
</div>
</div>
</center>
<div class="div2">
<div class="illustrator" style="background-image:url(./image\ 3.jpg);" >
<div class="iamCol">
<div class="scroller">
<div class="inner">
<p>RELIABLE</p>
<p>MANAGE</p>
<p>STORE</p>
<p>RETRIEVE</p>       
</div>
</div>
</div>
</div>

<div class="login">
<div class="container">
<div class="login-form">
            
                    <form action="" method="post">
                        <h1 style="margin-left: 100px; color: black;">Please Login</h1>
                        <div>
                            <input type="text" class="" name="username" placeholder="Username" autofocus='autofocus' required />
                        
                            <input type="text" class="" name="password" placeholder="Password" required />
                    
								<button class="" type="submit" name="login" style="margin-top: 10px; width: 200px;"> Log in</button>
                        

                     
                            
                               
                        </div>
                        
                    </form>

                    
        


<?php
include('include/dbcon.php');

if (isset($_POST['login'])){

$username=$_POST['username'];
$password=$_POST['password'];

$login_query=mysqli_query($con,"select * from admin where username='$username' and password='$password'");
$count=mysqli_num_rows($login_query);
$row=mysqli_fetch_array($login_query);

if ($count > 0){
session_start();
$_SESSION['id']=$row['admin_id'];

echo "<script>window.location='home.php'</script>";
}else{ ?>
<div class="alert alert-danger"><h3 class="blink_text">Access Rejected</h3></div>		
<?php
}
}
?>
             
            </div>
        </div>
    </div>
<footer style="margin-left: 300px;">Uganda Martyrs Archbishop Library Management System</h1><br>

© <?php echo date('Y'); ?>  Library Management System
</footer>
</body>

</html>



