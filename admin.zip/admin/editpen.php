<?php
	include ('dbcon.php');
	$id=$_GET['id'];
	$query=mysqli_query($con,"select * from `return_book` where user_id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./home.css">
<title>edit penalties</title>
</head>
<body>
<br><br><br><br>
<center>
	<div style="border-color: blue; background-color: rgb(103, 70, 134); border-radius:20px; width:700px; height:400px;">
	<h2><u>Edit Pentalty For Library Members</u></h2>
	<form method="POST" action="updatepen.php?id=<?php echo $id; ?>">
		<label><b>ENTER USER ID : </b></label><input type="text" value="<?php echo $row['user_id']; ?>" name="user_id"><br><br><br>
		<label><b>ENTER PENALTY : </b></label><input type="text" value="<?php echo $row['book_penalty']; ?>" name="book_penalty"><br><br><br>
		
		<input type="submit" name="submit" style="width:100px; height:40px; background-color:chartreuse;"><br><br><br>

		<a href="index2.php"><button style="width:100px; height:40px; background-color:pink;">Back</button></a>
	</form>
</div>
</center>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</body>
</html>
<?php include('footer.php'); ?>