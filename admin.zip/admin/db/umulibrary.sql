-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2023 at 02:44 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umulibrary`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirm_password` varchar(100) NOT NULL,
  `admin_image` varchar(100) NOT NULL,
  `admin_type` varchar(100) NOT NULL,
  `admin_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `confirm_password`, `admin_image`, `admin_type`, `admin_added`) VALUES
(1, 'OCAYA', 'ISAAC', 'DANIEL', 'DENZER', 'admin', 'admin', '11415472_722239274552218_7157581731732339970_o.jpg', 'Admin', '2015-09-05 11:40:50'),
(8, 'ANGEL', 'MALAIKA', 'KITIIBWA', 'ANGELA', 'angel22', 'angel22', '256708094242_status_cd6fa4bd88d242b3bed89e74defe6005.jpg', 'Admin', '2023-04-16 15:17:23');

-- --------------------------------------------------------

--
-- Table structure for table `allowed_book`
--

CREATE TABLE `allowed_book` (
  `allowed_book_id` int(11) NOT NULL,
  `qntty_books` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allowed_book`
--

INSERT INTO `allowed_book` (`allowed_book_id`, `qntty_books`) VALUES
(1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `allowed_days`
--

CREATE TABLE `allowed_days` (
  `allowed_days_id` int(11) NOT NULL,
  `no_of_days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allowed_days`
--

INSERT INTO `allowed_days` (`allowed_days_id`, `no_of_days`) VALUES
(1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `barcode`
--

CREATE TABLE `barcode` (
  `barcode_id` int(11) NOT NULL,
  `pre_barcode` varchar(100) NOT NULL,
  `mid_barcode` int(100) NOT NULL,
  `suf_barcode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barcode`
--

INSERT INTO `barcode` (`barcode_id`, `pre_barcode`, `mid_barcode`, `suf_barcode`) VALUES
(1, '8UMU8', 1, 'LIB'),
(2, '8UMU8', 2, 'LIB'),
(3, '8UMU8', 3, 'LIB'),
(4, '8UMU8', 4, 'LIB'),
(5, '8UMU8', 5, 'LIB'),
(6, '8UMU8', 6, 'LIB'),
(7, '8UMU8', 7, 'LIB'),
(8, '8UMU8', 8, 'LIB'),
(9, '8UMU8', 8, 'LIB'),
(10, '8UMU8', 8, 'LIB'),
(11, '8UMU8', 8, 'LIB'),
(12, '8UMU8', 8, 'LIB'),
(13, '8UMU8', 8, 'LIB'),
(14, 'VNHS', 8, 'LMS'),
(15, '8UMU8', 8, 'LIB'),
(16, '8UMU8', 8, 'LIB'),
(17, '8UMU8', 8, 'LIB'),
(18, '8UMU8', 8, 'LIB'),
(19, '8UMU8', 9, 'LIB'),
(20, '8UMU8', 10, 'LIB'),
(21, '8UMU8', 8, 'LIB'),
(22, 'VNHS', 11, 'LMS'),
(23, '8UMU8', 12, 'LIB'),
(24, '8UMU8', 13, 'LIB'),
(25, '8UMU8', 14, 'LIB'),
(26, '8UMU8', 15, 'LIB');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `category_id` int(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `author_2` varchar(100) NOT NULL,
  `author_3` varchar(100) NOT NULL,
  `author_4` varchar(100) NOT NULL,
  `author_5` varchar(100) NOT NULL,
  `book_copies` int(11) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `book_barcode` varchar(100) NOT NULL,
  `book_image` varchar(100) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `book_title`, `category_id`, `author`, `author_2`, `author_3`, `author_4`, `author_5`, `book_copies`, `publisher_name`, `book_barcode`, `book_image`, `date_added`) VALUES
(1, 'INFORMATION TECHNOLOGY', 4, 'Mr Kalema', '', '', '', '', 18, '', '8UMU812LIB', 'information technology book.jpg', '2023-05-05 00:40:49'),
(49, 'E-COMMERCE', 1, 'MADAM VIOLA', '', '', '', '', 8, '', '8UMU813LIB', 'commerce.jpg', '2023-05-06 01:01:10'),
(50, 'UNDERSTANDING MATHEMATICS', 3, 'john', '', '', '', '', 4, '', '8UMU814LIB', 'math.jpg', '2023-05-26 11:18:20'),
(51, 'Math', 3, 'Mr Kalema', '', '', '', '', 5, '', '8UMU815LIB', 'math.jpg', '2023-05-26 15:26:04');

-- --------------------------------------------------------

--
-- Table structure for table `borrow_book`
--

CREATE TABLE `borrow_book` (
  `borrow_book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `date_borrowed` datetime NOT NULL,
  `due_date` datetime NOT NULL,
  `date_returned` datetime NOT NULL,
  `borrowed_status` varchar(100) NOT NULL,
  `book_penalty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrow_book`
--

INSERT INTO `borrow_book` (`borrow_book_id`, `user_id`, `book_id`, `date_borrowed`, `due_date`, `date_returned`, `borrowed_status`, `book_penalty`) VALUES
(3, 4, 7, '2015-12-14 02:51:59', '2015-12-17 02:51:59', '2015-12-14 02:57:45', 'returned', 'No Penalty'),
(7, 20, 7, '2015-12-14 03:09:07', '2015-12-17 03:09:07', '2023-05-01 06:51:31', 'returned', '13460772'),
(38, 1, 49, '2023-05-17 00:32:16', '2023-05-20 00:32:16', '2023-05-17 00:33:49', 'returned', 'No Penalty'),
(39, 3, 49, '2023-05-17 02:50:46', '2023-05-20 02:50:46', '2023-05-26 16:19:01', 'returned', '32806'),
(40, 3, 1, '2023-05-26 20:20:51', '2023-05-29 20:20:51', '2023-05-26 20:21:25', 'returned', 'No Penalty');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `classname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `classname`) VALUES
(1, 'Textbook'),
(2, 'English'),
(3, 'Math'),
(4, 'Science'),
(5, 'Encyclopedia'),
(6, 'ugandan'),
(7, 'Novel'),
(8, 'General'),
(9, 'References');

-- --------------------------------------------------------

--
-- Table structure for table `penalty`
--

CREATE TABLE `penalty` (
  `penalty_id` int(11) NOT NULL,
  `penalty_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penalty`
--

INSERT INTO `penalty` (`penalty_id`, `penalty_amount`) VALUES
(1, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `poll`
--

CREATE TABLE `poll` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `feedback` text NOT NULL,
  `suggestions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `poll`
--

INSERT INTO `poll` (`id`, `name`, `email`, `phone`, `feedback`, `suggestions`) VALUES
(1, 'lecho', 'lecho@gmail.com', '7456453434363', 'excellent', 'bad');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `detail_action` varchar(100) NOT NULL,
  `date_transaction` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `book_id`, `user_id`, `detail_action`, `date_transaction`) VALUES
(170, 1, 1, 'Borrowed Book', '2023-05-05 20:44:53'),
(171, 1, 1, 'Returned Book', '2023-05-05 20:44:54'),
(172, 1, 1, 'Borrowed Book', '2023-05-06 00:51:01'),
(173, 1, 1, 'Returned Book', '2023-05-06 00:55:03'),
(182, 49, 1, 'Borrowed Book', '2023-05-16 19:32:18'),
(183, 49, 1, 'Returned Book', '2023-05-16 19:33:49'),
(184, 49, 3, 'Returned Book', '2023-05-26 11:18:59'),
(185, 49, 3, 'Returned Book', '2023-05-26 11:19:01'),
(186, 1, 3, 'Borrowed Book', '2023-05-26 15:20:59'),
(187, 1, 3, 'Returned Book', '2023-05-26 15:21:25');

-- --------------------------------------------------------

--
-- Table structure for table `return_book`
--

CREATE TABLE `return_book` (
  `return_book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `date_borrowed` datetime NOT NULL,
  `due_date` datetime NOT NULL,
  `date_returned` datetime NOT NULL,
  `book_penalty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return_book`
--

INSERT INTO `return_book` (`return_book_id`, `user_id`, `book_id`, `date_borrowed`, `due_date`, `date_returned`, `book_penalty`) VALUES
(1, 2, 7, '2015-11-14 02:50:27', '2015-11-17 02:50:27', '2015-12-14 02:57:31', '5000'),
(2, 1, 7, '2015-11-14 02:50:58', '2015-11-17 02:50:58', '2015-12-14 02:57:30', '5000'),
(148, 1, 49, '2023-05-17 00:32:16', '2023-05-20 00:32:16', '2023-05-17 00:32:18', 'No Penalty'),
(149, 1, 49, '2023-05-17 00:32:16', '2023-05-20 00:32:16', '2023-05-17 00:32:18', 'No Penalty'),
(150, 3, 49, '2023-05-17 02:50:46', '2023-05-20 02:50:46', '2023-05-26 16:18:54', '32806'),
(151, 3, 49, '2023-05-17 02:50:46', '2023-05-20 02:50:46', '2023-05-26 16:18:59', '32806'),
(152, 3, 1, '2023-05-26 20:20:51', '2023-05-29 20:20:51', '2023-05-26 20:20:59', 'No Penalty');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `school_number` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `user_image` varchar(100) NOT NULL,
  `presence` varchar(100) NOT NULL,
  `user_added` datetime NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirm_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `school_number`, `firstname`, `middlename`, `lastname`, `contact`, `gender`, `Email`, `type`, `faculty`, `user_image`, `presence`, `user_added`, `password`, `confirm_password`) VALUES
(1, '2345678', 'ocaya ', '', 'isaac', '0787644403', 'Male', '', 'Student', 'FOBE', '', 'Active', '2023-04-16 12:59:44', 'better', 'better'),
(3, '326767676', 'angela', '', 'kitiibwa', '', 'Female', '', 'Student', 'Education', '', 'Active', '2023-05-05 20:22:50', 'good', 'good'),
(52, '2021', 'tree', '', 'tre', '', 'Male', '', 'Student', 'Science', 'picture.jpg', 'Active', '2023-05-21 15:49:40', 'rer', 'rer'),
(53, '5666556', 'ayebale', '', 'tony', '0787644403', 'Male', 'aye@mail.com', 'Student', 'Science', 'MUSEVENI.jpg', '', '2023-05-26 11:15:54', 'ayeaye', 'ayeaye');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `allowed_book`
--
ALTER TABLE `allowed_book`
  ADD PRIMARY KEY (`allowed_book_id`);

--
-- Indexes for table `allowed_days`
--
ALTER TABLE `allowed_days`
  ADD PRIMARY KEY (`allowed_days_id`);

--
-- Indexes for table `barcode`
--
ALTER TABLE `barcode`
  ADD PRIMARY KEY (`barcode_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `borrow_book`
--
ALTER TABLE `borrow_book`
  ADD PRIMARY KEY (`borrow_book_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_id` (`category_id`),
  ADD KEY `classid` (`category_id`);

--
-- Indexes for table `penalty`
--
ALTER TABLE `penalty`
  ADD PRIMARY KEY (`penalty_id`);

--
-- Indexes for table `poll`
--
ALTER TABLE `poll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `return_book`
--
ALTER TABLE `return_book`
  ADD PRIMARY KEY (`return_book_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `allowed_book`
--
ALTER TABLE `allowed_book`
  MODIFY `allowed_book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `allowed_days`
--
ALTER TABLE `allowed_days`
  MODIFY `allowed_days_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `barcode`
--
ALTER TABLE `barcode`
  MODIFY `barcode_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `borrow_book`
--
ALTER TABLE `borrow_book`
  MODIFY `borrow_book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=801;

--
-- AUTO_INCREMENT for table `penalty`
--
ALTER TABLE `penalty`
  MODIFY `penalty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `poll`
--
ALTER TABLE `poll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;

--
-- AUTO_INCREMENT for table `return_book`
--
ALTER TABLE `return_book`
  MODIFY `return_book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
