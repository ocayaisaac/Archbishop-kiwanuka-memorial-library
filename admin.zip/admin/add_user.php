<link rel="stylesheet" href="./add_admin.css"/>
<?php include ('header.php'); ?>
<br><br><br><br><br><br>
        <center>
                <h3>
					Add a Library Member
                </h3>
     

                            <form method="post" enctype="multipart/form-data" class="form-horizontal form-label-left">
                               
                            
                            <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">ID Number <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-2">
                                        <input type="number" name="school_number" id="first-name2" required="required" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">First Name <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-3">
                                        <input type="text" name="firstname" placeholder="" id="first-name2" required="required" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="first-name">Middle Name
                                    </label>
                                    <div class="col-md-3">
                                        <input type="text" name="middlename" placeholder="" id="first-name2" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Last Name <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-3">
                                        <input type="text" name="lastname" placeholder="" id="last-name2" required="required" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Contact
                                    </label>
                                    <div class="col-md-3">
                                        <input type="tel" pattern="[0-9]{10,10}" autocomplete="off"  maxlength="10" name="contact" id="last-name2" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Gender <span class="required" style="color:red;">*</span>
                                    </label>
									<div class="col-md-4">
                                        <select name="gender" class="select2_single form-control" required="required" tabindex="-1" >
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                </div>								
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Email
                                    </label>
                                    <div class="col-md-4">
                                        <input type="text" name="Email" id="last-name2" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
									<label class="control-label col-md-4" for="last-name">Type <span class="required" style="color:red;">*</span>
									</label>
									<div class="col-md-4">
                                        <select name="type" class="select2_single form-control" required="required" tabindex="-1" >
                                            <option value="Student">Student</option>
                                            <option value="Lecturer">Lecturer</option>
                                        </select>
                                    </div>
                                    </div>
                                <div class="form-group">
									<label class="control-label col-md-4" for="last-name">Faculty <span class="required" style="color:red;">*</span>
									</label>
                                    
									<div class="col-md-4">
                                        <select name="faculty" class="select2_single form-control" required="required" tabindex="-1" >
                                            <option value="Science">Science</option>
                                            <option value="Agriculture">Agriculture</option>
                                            <option value="ILACS">ILACS</option>
                                            <option value="SASS">SASS</option>
                                            <option value="Fobe">FOBE</option>
                                            <option value="Education">Education</option>
                                            <option value="Bam">BAM</option>
                                            <option value="Law">LAW</option>
                                        </select>
                                </div>
                                    </div>
                              
                        <br>
                        <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Password <span class="required" style="color:red;">*</span>
                                    </label>
                                    
                                        <input type="password" name="password" id="last-name2" required="required" class="form-control col-md-2 col-xs-5" style="width:400px;">
                                    </div>
                                
                                    <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">Confirm Password <span class="required" style="color:red;">*</span>
                                    </label>
                                    <div class="col-md-4">
                                        <input type="password" name="confirm_password" id="last-name2" required="required" class="form-control col-md-7 col-xs-12">
                                    </div>
                                    <br>

                                    <div class="form-group">
                                    <label class="control-label col-md-4" for="last-name">User Image
                                    </label>
                                    <div class="col-md-4">
                                        <input type="file" style="height:44px;" name="image" id="last-name2" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div><br><br>

                                        <a href="user.php"><button type="button" class="cancelbutton"> Cancel</button></a><br><br>
                                        <button type="submit" name="submit" class="submitbutton"></i> Submit</button>
                                    </div>
                               
                            </form>
							
							<?php	
							include ('include/dbcon.php');
                            if (!isset($_FILES['image']['tmp_name'])) {
                                echo "";
                                }else{
                                $file=$_FILES['image']['tmp_name'];
                                $image = $_FILES["image"] ["name"];
                                $image_name= addslashes($_FILES['image']['name']);
                                $size = $_FILES["image"] ["size"];
                                $error = $_FILES["image"] ["error"];
                                {
                                            if($size > 10000000) 
                                            {
                                            die("Format is not allowed or file size is too big!");
                                            }
                                            
                                        else
                                            {
    
                                        move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $_FILES["image"]["name"]);			
                                        $profile=$_FILES["image"]["name"];
									$school_number = $_POST['school_number'];
									$firstname = $_POST['firstname'];
									$middlename = $_POST['middlename'];
									$lastname = $_POST['lastname'];
									$contact = $_POST['contact'];
									$gender = $_POST['gender'];
									$Email = $_POST['Email'];
									$type = $_POST['type'];
									$faculty = $_POST['faculty'];
									$password = $_POST['password'];
									$confirm_password = $_POST['confirm_password'];
					
					$result=mysqli_query($con,"select * from user WHERE school_number='$school_number' ") or die (mysqli_error());
					$row=mysqli_num_rows($result);
					if ($row > 0)
					{
					echo "<script>alert('ID Number already active!'); window.location='add_user.php'</script>";
				}
                elseif($password != $confirm_password)
                {
                echo "<script>alert('Password do not match!'); window.location='add_user.php'</script>";
                }else
                {			
						mysqli_query($con,"insert into user (school_number,firstname, middlename, lastname, contact, gender, Email, type, faculty, password, confirm_password, user_image, user_added)
						values ('$school_number','$firstname', '$middlename', '$lastname', '$contact', '$gender', '$Email', '$type', '$faculty', '$password','$confirm_password', '$profile', NOW())")or die(mysqli_error());
						echo "<script>alert('User successfully added!'); window.location='user.php'</script>";
					}
                }
            }
        
							}
								?>
</center>                        
            
<?php include ('footer.php'); ?>