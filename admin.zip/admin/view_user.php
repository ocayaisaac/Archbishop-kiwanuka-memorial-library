<?php include ('header.php'); ?>

      <center>
                <h3>
					View User
                </h3>

							<table cellpadding="13" cellspacing="1" border="2">
								
							<thead>
								<tr>
						<th>User Image</th>
									<th style="width:200px;">Member Full Name</th>
									<th style="width:200px;">Contact</th>
									<th style="width:200px;">Gender</th>
									<th style="width:200px;">Email</th>
									<th style="width:200px;">Type</th>
									<th style="width:200px;">Faculty</th>
									<th style="width:200px;">Presence</th>
									<th style="width:200px;">User Added</th>
								</tr>
							</thead>
							<tbody>
<?php
			   
		if (isset($_GET['user_id']))
		$id=$_GET['user_id'];
		$result1 = mysqli_query($con,"SELECT * FROM user WHERE user_id='$id'");
		while($row = mysqli_fetch_array($result1)){
		?>
							<tr>
							<td>
					<?php  if($row['user_image'] != ""): ?>
								<img src="upload/<?php  echo $row['user_image']; ?>" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
								<?php  else: ?>
								<img src="images/user.png" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
								<?php  endif; ?>
								</td>
								<td><?php echo $row['firstname']." ".$row['middlename']." ".$row['lastname']; ?></td> 
								<td><?php echo $row['contact']; ?></td> 
								<td><?php echo $row['gender']; ?></td> 
								<td><?php echo $row['Email']; ?></td> 
								<td><?php echo $row['type']; ?></td> 
								<td><?php echo $row['faculty']; ?></td> 
								<td><?php echo $row['presence']; ?></td>
								
								<td><?php echo date("M d, Y h:m:s a", strtotime($row['user_added'])); ?></td>
							</tr>
							<?php } ?>
							</tbody>
							</table>
							</center><BR><BR><BR>
<?php include ('footer.php'); ?>