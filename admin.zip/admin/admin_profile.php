<?php include ('header.php'); ?>
<br><br><br><br><br><br>
    <center>
                <h3>
					Admin Profile Information
                </h3>

<?php
$user_query  = mysqli_query($con,"select * from admin where admin_id = '$id_session'")or die(mysqli_error());
$user_row =mysqli_fetch_array($user_query);
$admin_type  = $user_row['admin_type'];
?>
					<?php if ($admin_type == 'Admin') {
					?>
                            
							<a href="add_admin.php" style="background:none;">
							<button class="btn btn-primary"><i class="fa fa-plus"></i> Add Admin</button>
							</a>
							
					<?php } ?>
                  <br>
					
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
								
							<thead>
								<tr>
									<th>Image</th>
									<th>FirstName</th>
									<th>LastName</th>
							
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							
							<?php
							$result= mysqli_query($con,"select * from admin where admin_id = '".$_SESSION['id']."' order by admin_id DESC") or die (mysqli_error());
							while ($row= mysqli_fetch_array ($result) ){
							$id=$row['admin_id'];
							?>
							<tr>
								<td>
									<?php if($row['admin_image'] != ""): ?>
									<img src="upload/<?php echo $row['admin_image']; ?>" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
									<?php else: ?>
									<img src="images/user.png" width="100px" height="100px" style="border:4px groove #CCCCCC; border-radius:5px;">
									<?php endif; ?>	
								</td> 
								<td><?php echo $row['firstname']; ?></td> 
								<td><?php echo $row['lastname']; ?></td>
						
								<td>
									<a class="btn btn-primary" for="ViewAdmin" href="view_admin.php<?php echo '?admin_id='.$id; ?>">
										<i class="fa fa-search">View Admin</i>
									</a>
									<a class="btn btn-warning" for="ViewAdmin" href="edit_admin.php<?php echo '?admin_id='.$id; ?>">
										<i class="fa fa-edit">Edit Amin</i>
									</a>
									
			
					
									<div id="delete<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									

												<a href="delete_admin.php<?php echo '?admin_id='.$id; ?>" style="margin-top:20px; background-color:red;" class="btn btn-primary">Delete Admin</a>
												</div>
										</div>
									
								</td> 
							</tr>
							<?php } ?>
							</tbody>
							</table>
		

<?php include ('footer.php'); ?>